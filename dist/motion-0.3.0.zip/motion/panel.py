"""IngeTrazo side panel: define a mechanism on the model, play it, check it.

How it is used (all from the current selection):

- Pièce fixe / Pièce mobile: the selected groups become one body.
- Pivot / Glissière: ONE selected edge (or construction line) gives the
  axis (pivot) or the direction (slider); the two nearest bodies are joined.
- Guide / rail: select the rail's edges (lines and arc segments, smooth)
  plus one short mark per roller, drawn across the rail where the roller
  is; each roller is joined to the nearest moving body.
- Moteur 0–100 %: makes the joint chosen in the list the driver, with the
  travel typed under it.
- Valider: runs 0..100 % and reports convergence, collisions, stops and
  the smallest clearance against the minimum gap.
- Trajectoire: traces the end points of the selected edges (else the joint
  points) through the motion.

The animation is drawn OVER the model (an overlay): the model's groups do
not move, so playing never adds undo steps. The mechanism itself is kept in
the document (``app.set_document_data``), one undo step per edit.
"""
import math
import numpy as np
from PySide6.QtCore import QPointF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QPen
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox,
                               QDoubleSpinBox, QFormLayout, QGridLayout,
                               QGroupBox, QHBoxLayout, QLabel, QPlainTextEdit,
                               QSlider, QSpinBox, QToolButton, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

from . import collide, document as doc, icons, samples, solver

SOURCES = (("model", "Modèle (document)"),
           ("chaise", "Exemple : chaise pliante"),
           ("porte", "Exemple : porte sectionnelle"))

TIPS = {
    "fixed": "Pièce fixe (Fixed part) — les groupes sélectionnés forment le bâti.",
    "moving": "Pièce mobile (Moving part) — les groupes sélectionnés bougent ensemble.",
    "pivot": "Pivot — sélectionner UNE arête ou ligne de construction sur l'axe.",
    "slider": "Glissière (Slider) — sélectionner UNE arête dans le sens du coulissement.",
    "guide": "Guide / rail — sélectionner les arêtes du rail + un petit trait en travers à chaque galet.",
    "driver": "Moteur 0–100 % (Driver) — la liaison choisie dans la liste, avec la course indiquée.",
    "validate": "Valider (Validate) — de 0 à 100 % : collisions, butées, jeu minimal.",
    "trajectory": "Trajectoire (Trajectory) — trace les extrémités des arêtes sélectionnées.",
}


# -- reading the IngeTrazo scene (kept here, in one place) ----------------------

def _xyz(p):
    return np.array([p.x(), p.y(), p.z()], float)


def _placements(group):
    """(mesh, (rot, trans) | None) for the group and its nested placements."""
    try:
        from core.group import iter_placements, np_affine
    except Exception:                      # outside IngeTrazo (tests)
        yield group.mesh, None
        return
    for g, m in iter_placements(group):
        yield g.mesh, (None if m is None else np_affine(m))


def group_points(group):
    out = []
    for mesh, aff in _placements(group):
        if not mesh.vertices:
            continue
        P = np.array([_xyz(v.position) for v in mesh.vertices])
        out.append(P if aff is None else P @ aff[0].T + aff[1])
    return np.vstack(out) if out else np.zeros((0, 3))


def group_segments(group):
    out = []
    for mesh, aff in _placements(group):
        segs = [(_xyz(e.v0.position), _xyz(e.v1.position)) for e in mesh.edges
                if not getattr(e, "hidden", False)]
        if not segs:
            continue
        S = np.array(segs)
        if aff is not None:
            S = S @ aff[0].T + aff[1]
        out.append(S)
    return np.vstack(out) if out else np.zeros((0, 2, 3))


def groups_by_uid(scene):
    f = getattr(scene, "groups_by_uid", None)
    if callable(f):
        return f()
    return {g.uid: g for g in getattr(scene, "groups", [])}


def selection(scene):
    """(groups, segments) of the current selection."""
    groups, segs = [], []
    for ent in list(getattr(scene, "selection", ()) or ()):
        if hasattr(ent, "mesh") and hasattr(ent, "uid"):
            groups.append(ent)
        elif hasattr(ent, "v0") and hasattr(ent, "v1"):          # Edge
            segs.append((_xyz(ent.v0.position), _xyz(ent.v1.position)))
        elif hasattr(ent, "a") and hasattr(ent, "b"):            # construction line
            try:
                segs.append((_xyz(ent.a), _xyz(ent.b)))
            except Exception:
                pass
    return groups, segs


# -- the panel ------------------------------------------------------------------------

class MotionPanel(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.source = "model"
        self.data = doc.empty()
        self.mech = None
        self.problems = []
        self.frames = None          # validate() rows, or None
        self.report = None
        self.x = None               # pose shown now
        self.t = 0.0
        self.traces = []            # (body, point) followed by Trajectory
        self.trace_pts = []
        self.body_segments = {}     # body name -> (M, 2, 3) reference segments
        self._build_ui()
        self.timer = QTimer(self)
        self.timer.setInterval(40)
        self.timer.timeout.connect(self._tick)
        self.reload()

    # ---- UI -------------------------------------------------------------------------
    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)
        self.src = QComboBox()
        for key, text in SOURCES:
            self.src.addItem(text, key)
        self.src.currentIndexChanged.connect(self._source_changed)
        lay.addWidget(self.src)

        grid = QGridLayout()
        grid.setSpacing(2)
        self.buttons = {}
        for i, name in enumerate(icons.NAMES):
            b = QToolButton()
            b.setIcon(icons.icon(name, self, 24))
            b.setIconSize(QSize(24, 24))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
            b.setText(icons.LABELS[name][0])
            b.setToolTip(TIPS[name])
            b.setAutoRaise(True)
            b.setMinimumWidth(10)
            b.clicked.connect(lambda _c=False, n=name: self._action(n))
            grid.addWidget(b, i // 4, i % 4)
            self.buttons[name] = b
        self.buttons["trajectory"].setCheckable(True)
        lay.addLayout(grid)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Nom", "Type", "Détail"])
        self.tree.setRootIsDecorated(False)
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.itemSelectionChanged.connect(self._item_selected)
        lay.addWidget(self.tree, 1)

        row = QHBoxLayout()
        self.delete_btn = QToolButton()
        self.delete_btn.setText("Supprimer")
        self.delete_btn.clicked.connect(self._delete)
        row.addWidget(self.delete_btn)
        row.addStretch(1)
        lay.addLayout(row)

        box = QGroupBox("Liaison choisie")
        form = QFormLayout(box)
        self.combo_a, self.combo_b = QComboBox(), QComboBox()
        form.addRow("Pièce A", self.combo_a)
        form.addRow("Pièce B", self.combo_b)
        self.lim_on = QCheckBox("Butées")
        self.lim_lo, self.lim_hi = self._spin(), self._spin()
        lr = QHBoxLayout()
        lr.addWidget(self.lim_on)
        lr.addWidget(self.lim_lo)
        lr.addWidget(self.lim_hi)
        form.addRow(lr)
        self.drv_lo, self.drv_hi = self._spin(), self._spin()
        dr = QHBoxLayout()
        dr.addWidget(self.drv_lo)
        dr.addWidget(QLabel("→"))
        dr.addWidget(self.drv_hi)
        self.unit = QLabel("")
        dr.addWidget(self.unit)
        form.addRow("Course moteur", dr)
        self.apply_btn = QToolButton()
        self.apply_btn.setText("Appliquer")
        self.apply_btn.clicked.connect(self._apply_joint)
        form.addRow(self.apply_btn)
        lay.addWidget(box)

        play = QHBoxLayout()
        self.play_btn = QToolButton()
        self.play_btn.setText("▶")
        self.play_btn.setToolTip("Lecture / pause")
        self.play_btn.setCheckable(True)
        self.play_btn.toggled.connect(self._play)
        play.addWidget(self.play_btn)
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 1000)
        self.slider.valueChanged.connect(self._scrub)
        play.addWidget(self.slider, 1)
        self.pct = QLabel("0 %")
        self.pct.setMinimumWidth(42)
        play.addWidget(self.pct)
        lay.addLayout(play)
        self.loop = QCheckBox("Aller-retour")
        self.loop.setChecked(True)
        prow = QHBoxLayout()
        prow.addWidget(self.loop)
        prow.addStretch(1)
        self.video_btn = QToolButton()
        self.video_btn.setText("Exporter la vidéo…")
        self.video_btn.setToolTip("Vidéo en écran partagé : la vue IngeTrazo à gauche, "
                                  "l'animation ombrée et les mesures à droite.")
        self.video_btn.clicked.connect(self._export_dialog)
        prow.addWidget(self.video_btn)
        lay.addLayout(prow)

        val = QHBoxLayout()
        val.addWidget(QLabel("Jeu mini"))
        self.jeu = QDoubleSpinBox()
        self.jeu.setRange(0, 100)
        self.jeu.setDecimals(1)
        self.jeu.setSuffix(" mm")
        self.jeu.setValue(5.0)
        val.addWidget(self.jeu)
        val.addWidget(QLabel("Pas"))
        self.pas = QSpinBox()
        self.pas.setRange(3, 401)
        self.pas.setValue(51)
        val.addWidget(self.pas)
        lay.addLayout(val)

        self.out = QPlainTextEdit()
        self.out.setReadOnly(True)
        self.out.setMaximumBlockCount(500)
        lay.addWidget(self.out, 1)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)

    @staticmethod
    def _spin():
        s = QDoubleSpinBox()
        s.setRange(-1e6, 1e6)
        s.setDecimals(1)
        return s

    def say(self, text):
        self.status.setText(text)
        win = getattr(self.app, "window", None)
        bar = getattr(win, "statusBar", None)
        try:
            if callable(bar):
                bar().showMessage(text, 6000)
        except Exception:
            pass

    # ---- data ---------------------------------------------------------------------
    def reload(self):
        """The document changed (edit, undo, New, Open)."""
        if self.source == "model":
            self.data = doc.normalized(self.app.document_data(default=None))
            self.jeu.blockSignals(True)
            self.jeu.setValue(1000 * self.data.get("jeu_min", 0.005))
            self.jeu.blockSignals(False)
            self.pas.setValue(int(self.data.get("pas", 51)))
        self._invalidate()
        self._fill_tree()

    def _store(self, data, message=""):
        data["jeu_min"] = self.jeu.value() / 1000
        data["pas"] = self.pas.value()
        self.data = data
        self.app.set_document_data(data)    # one undo step; reload follows
        self._invalidate()
        self._fill_tree()
        if message:
            self.say(message)

    def _invalidate(self):
        self.mech = None
        self.frames = None
        self.report = None
        self.x = None
        self.trace_pts = []

    def _scene(self):
        return self.app.scene

    def _boxes(self):
        by = groups_by_uid(self._scene())
        return doc.body_boxes(self.data, lambda u: group_points(by[u]) if u in by else None)

    def mechanism(self):
        """The current mechanism (built once per change)."""
        if self.mech is not None:
            return self.mech
        if self.source == "chaise":
            self.mech, info = samples.chaise_pliante()
            self.problems = []
        elif self.source == "porte":
            self.mech, info = samples.porte_sectionnelle()
            self.problems = []
        else:
            by = groups_by_uid(self._scene())
            self.mech, self.problems = doc.build(
                self.data, lambda u: group_points(by[u]) if u in by else None,
                lambda u: getattr(by.get(u), "name", None))
            self.body_segments = {}
            for b in self.data["bodies"]:
                segs = [group_segments(by[u]) for u in b["groups"] if u in by]
                segs = [s for s in segs if len(s)]
                if segs:
                    self.body_segments[b["name"]] = np.vstack(segs)
        if self.source != "model":
            self.body_segments = {}
        return self.mech

    def _fill_tree(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        if self.source == "model":
            bodies = [(b["name"], "fixed" if b["fixed"] else "moving",
                       f"{len(b['groups'])} groupe(s)") for b in self.data["bodies"]]
            joints = [(j["name"], j["kind"], f"{j['a']} ↔ {j['b']}")
                      for j in self.data["joints"]]
            drv = (self.data["driver"] or {}).get("joint")
        else:
            m = self.mechanism()
            bodies = [(m.ground.name, "fixed", "")] + [(b.name, "moving", "")
                                                       for b in m.bodies]
            joints = [(j.name, j.kind, f"{j.a.name} ↔ {j.b.name}") for j in m.joints]
            drv = m.driver[0].name if m.driver else None
        kinds = {"fixed": "Pièce fixe", "moving": "Pièce mobile", "pivot": "Pivot",
                 "slider": "Glissière", "guide": "Guide / rail"}
        for name, kind, detail in bodies + joints:
            it = QTreeWidgetItem([name, kinds[kind], detail])
            it.setIcon(0, icons.icon(kind, self.tree, 16))
            it.setData(0, Qt.UserRole, name)
            if name == drv:
                it.setIcon(1, icons.icon("driver", self.tree, 16))
                it.setText(1, kinds[kind] + " · moteur")
            self.tree.addTopLevelItem(it)
        for c in range(3):
            self.tree.resizeColumnToContents(c)
        self.tree.blockSignals(False)
        editable = self.source == "model"
        for n in ("fixed", "moving", "pivot", "slider", "guide"):
            self.buttons[n].setEnabled(editable)
        self.delete_btn.setEnabled(editable)
        self.apply_btn.setEnabled(editable)
        names = [b["name"] for b in self.data["bodies"]] if editable else []
        for c in (self.combo_a, self.combo_b, self.lim_on, self.lim_lo, self.lim_hi):
            c.setEnabled(editable)
        for c in (self.combo_a, self.combo_b):
            c.blockSignals(True)
            c.clear()
            c.addItems(names)
            c.blockSignals(False)
        if drv:                                  # show the driver's travel
            hit = self.tree.findItems(drv, Qt.MatchExactly)
            if hit:
                self.tree.setCurrentItem(hit[0])

    def _chosen(self):
        it = self.tree.currentItem()
        return it.data(0, Qt.UserRole) if it is not None else None

    def _joint_record(self, name):
        for j in self.data["joints"]:
            if j["name"] == name:
                return j
        return None

    def _is_angle(self, kind):
        return kind == "pivot"

    def _to_ui(self, kind, v):
        return math.degrees(v) if self._is_angle(kind) else 1000 * v

    def _from_ui(self, kind, v):
        return math.radians(v) if self._is_angle(kind) else v / 1000

    def _item_selected(self):
        name = self._chosen()
        if self.source != "model":
            j = next((j for j in self.mechanism().joints if j.name == name), None)
            if j is not None:
                self._show_travel(j.kind, j, None)
            return
        j = self._joint_record(name)
        if j is None:
            return
        self.combo_a.setCurrentText(j["a"])
        self.combo_b.setCurrentText(j["b"])
        lim = j.get("limits")
        self.lim_on.setChecked(bool(lim))
        if lim:
            self.lim_lo.setValue(self._to_ui(j["kind"], lim[0]))
            self.lim_hi.setValue(self._to_ui(j["kind"], lim[1]))
        mj = next((k for k in self.mechanism().joints if k.name == name), None)
        self._show_travel(j["kind"], mj, j)

    def _show_travel(self, kind, mj, rec):
        self.unit.setText("°" if self._is_angle(kind) else "mm")
        drv = self.data.get("driver") if self.source == "model" else None
        m = self.mechanism()
        if self.source != "model" and m.driver and m.driver[0] is mj:
            lo, hi = m.driver[1], m.driver[2]
        elif drv and rec and drv["joint"] == rec["name"]:
            lo, hi = drv["lo"], drv["hi"]
        else:
            lo = m.joint_value(mj, np.zeros(m.n)) if mj is not None else 0.0
            if kind == "pivot":
                hi = lo + math.pi / 2
            elif kind == "guide" and mj is not None:
                hi = mj.path.length
            else:
                hi = lo + 0.1
        self.drv_lo.setValue(self._to_ui(kind, lo))
        self.drv_hi.setValue(self._to_ui(kind, hi))

    # ---- actions --------------------------------------------------------------------
    def _action(self, name):
        try:
            getattr(self, "_do_" + name)()
        except Exception as exc:          # never break the app; say why
            self.say(f"{icons.LABELS[name][0]} : {exc}")
        self.app.viewport.update()

    def _do_fixed(self, fixed=True):
        groups, _ = selection(self._scene())
        if not groups:
            self.say("Sélectionner un ou plusieurs groupes.")
            return
        d, name = doc.add_body(self.data, [g.uid for g in groups], fixed)
        self._store(d, f"{name} : {len(groups)} groupe(s).")

    def _do_moving(self):
        self._do_fixed(False)

    def _two_bodies(self, point):
        boxes = self._boxes()
        if len(boxes) < 2:
            raise ValueError("définir d'abord au moins deux pièces")
        b1 = doc.nearest_body(point, boxes)
        b2 = doc.nearest_body(point, boxes, exclude=(b1,))
        fixed = {b["name"] for b in self.data["bodies"] if b["fixed"]}
        return (b2, b1) if b1 not in fixed and b2 in fixed else (b1, b2)

    def _one_segment(self):
        _, segs = selection(self._scene())
        if len(segs) != 1:
            raise ValueError("sélectionner UNE arête (ou ligne de construction)")
        p0, p1 = segs[0]
        if np.linalg.norm(p1 - p0) < 1e-9:
            raise ValueError("arête de longueur nulle")
        return p0, p1

    def _do_pivot(self, kind="pivot"):
        p0, p1 = self._one_segment()
        a, b = self._two_bodies((p0 + p1) / 2)
        d, name = doc.add_joint(self.data, kind, a, b, point=p0 if kind == "slider"
                                else (p0 + p1) / 2, axis=p1 - p0)
        self._store(d, f"{name} : {a} ↔ {b}.")

    def _do_slider(self):
        self._do_pivot("slider")

    def _do_guide(self):
        _, segs = selection(self._scene())
        if len(segs) < 2:
            raise ValueError("sélectionner le rail et un trait par galet")
        rail, rollers = doc.rail_and_rollers(segs)
        if not rollers:
            raise ValueError("aucun galet : tracer un petit trait en travers du rail")
        boxes = self._boxes()
        fixed = [b["name"] for b in self.data["bodies"] if b["fixed"]]
        if not fixed:
            raise ValueError("définir d'abord la pièce fixe qui porte le rail")
        a = doc.nearest_body(np.mean(rail, axis=0), {k: boxes[k] for k in fixed}) or fixed[0]
        d, names = self.data, []
        for r in rollers:
            b = doc.nearest_body(r, boxes, exclude=fixed)
            if b is None:
                raise ValueError("aucune pièce mobile près du galet")
            d, n = doc.add_joint(d, "guide", a, b, point=r, rail=rail)
            names.append(n)
        self._store(d, f"{len(names)} galet(s) sur le rail de {a}.")

    def _do_driver(self):
        name = self._chosen()
        if self.source != "model":
            m = self.mechanism()
            j = next((j for j in m.joints if j.name == name), m.driver[0])
            m.drive(j, self._from_ui(j.kind, self.drv_lo.value()),
                    self._from_ui(j.kind, self.drv_hi.value()))
            self.frames = None
            self._fill_tree()
            self.say(f"Moteur : {j.name}.")
            return
        j = self._joint_record(name)
        if j is None:
            if len(self.data["joints"]) == 1:
                j = self.data["joints"][0]
                self._show_travel(j["kind"], None, j)
            else:
                raise ValueError("choisir une liaison dans la liste")
        d = doc.set_driver(self.data, j["name"], self._from_ui(j["kind"], self.drv_lo.value()),
                           self._from_ui(j["kind"], self.drv_hi.value()))
        self._store(d, f"Moteur : {j['name']}.")

    def _apply_joint(self):
        j = self._joint_record(self._chosen())
        if j is None or self.source != "model":
            return
        d = doc.normalized(self.data)
        rec = next(k for k in d["joints"] if k["name"] == j["name"])
        rec["a"], rec["b"] = self.combo_a.currentText(), self.combo_b.currentText()
        rec["limits"] = ([self._from_ui(j["kind"], self.lim_lo.value()),
                          self._from_ui(j["kind"], self.lim_hi.value())]
                         if self.lim_on.isChecked() else None)
        if d["driver"] and d["driver"]["joint"] == j["name"]:
            d["driver"]["lo"] = self._from_ui(j["kind"], self.drv_lo.value())
            d["driver"]["hi"] = self._from_ui(j["kind"], self.drv_hi.value())
        self._store(d, f"{j['name']} mis à jour.")

    def _delete(self):
        name = self._chosen()
        if name and self.source == "model":
            self._store(doc.remove(self.data, name), f"{name} supprimé.")

    def _do_validate(self):
        m = self.mechanism()
        if m.driver is None:
            raise ValueError("pas de moteur")
        if self.source == "model":
            self.data["jeu_min"] = self.jeu.value() / 1000
            self.data["pas"] = self.pas.value()
        self.report = collide.validate(m, self.pas.value(), self.jeu.value() / 1000)
        self.frames = self.report["steps"]
        self._write_report()
        if self.buttons["trajectory"].isChecked():
            self._compute_traces()
        self._scrub(self.slider.value())

    def _write_report(self):
        rep, lines = self.report, []
        lines += [f"⚠ {p}" for p in self.problems]
        w = rep["worst"]
        if rep["ok"]:
            lines.append("✔ Mécanisme valide de 0 à 100 %.")
        else:
            lines.append(f"✖ {len(rep['problems'])} problème(s) :")
            lines += ["  " + p for p in rep["problems"][:60]]
            if len(rep["problems"]) > 60:
                lines.append("  …")
        if w is not None:
            lines.append(f"Jeu le plus faible : {w['distance'] * 1000:.1f} mm entre "
                         f"{w['a']} ({w['box_a']}) et {w['b']} ({w['box_b']}) "
                         f"à {round(100 * w['t'])} %.")
        lines.append(f"Degrés de liberté (sans moteur) : {solver.dof(self.mechanism(), self.frames[len(self.frames) // 2]['x'])}")
        self.out.setPlainText("\n".join(lines))

    def _do_trajectory(self):
        if not self.buttons["trajectory"].isChecked():
            self.traces, self.trace_pts = [], []
            return
        m = self.mechanism()
        _, segs = selection(self._scene())
        self.traces = []
        moving = {b.name: b for b in m.bodies}
        if segs and self.source == "model":
            boxes = {k: v for k, v in self._boxes().items() if k in moving}
            for p0, p1 in segs:
                for p in (p0, p1):
                    b = doc.nearest_body(p, boxes)
                    if b:
                        self.traces.append((moving[b], p))
        else:
            for j in m.joints:
                for body in (j.a, j.b):
                    if not body.fixed:
                        self.traces.append((body, np.asarray(j.point, float)))
                        break
        self._compute_traces()
        self.say(f"Trajectoire de {len(self.traces)} point(s).")

    def _compute_traces(self):
        m = self.mechanism()
        if self.frames is None:
            self.frames = solver.sweep(m, self.pas.value())
        self.trace_pts = [doc.trajectory(m, self.frames, b, p) for b, p in self.traces]

    # ---- playback -------------------------------------------------------------------
    def _source_changed(self):
        self.source = self.src.currentData()
        self.timer.stop()
        self.play_btn.setChecked(False)
        self.traces, self.trace_pts = [], []
        self.buttons["trajectory"].setChecked(False)
        self.out.clear()
        self.reload()
        self.slider.setValue(0)
        self._scrub(0)

    def set_source(self, key):
        i = [k for k, _ in SOURCES].index(key)
        self.src.setCurrentIndex(i)

    def _scrub(self, v):
        self.t = v / 1000.0
        self.pct.setText(f"{round(100 * self.t)} %")
        try:
            self._pose_at(self.t)
        except Exception as exc:
            self.say(f"Lecture : {exc}")
        self.app.viewport.update()

    def _pose_at(self, t):
        m = self.mechanism()
        if m.driver is None:
            self.x = np.zeros(m.n)
            return
        if self.frames:
            k = int(round(t * (len(self.frames) - 1)))
            self.x = self.frames[k]["x"]
            return
        j, lo, hi = m.driver
        x, ok, _ = solver.solve(m, lo + t * (hi - lo), self.x)
        self.x = x
        if not ok:
            self.say(f"{round(100 * t)} % : position non atteinte.")

    def _play(self, on):
        self.play_btn.setText("⏸" if on else "▶")
        if on:
            m = self.mechanism()
            if m.driver is not None and self.frames is None:
                self.frames = solver.sweep(m, self.pas.value())
            self._dir = 1
            self.timer.start()
        else:
            self.timer.stop()

    def _tick(self):
        v = self.slider.value() + self._dir * 10
        if v > 1000 or v < 0:
            if self.loop.isChecked():
                self._dir = -self._dir
                v = max(0, min(1000, v))
            else:
                v = 0
        self.slider.setValue(v)

    # ---- drawing over the viewport ----------------------------------------------------
    def paint(self, viewport, painter):
        m = self.mech
        if m is None or not (self.isVisible() or getattr(self, "_force_paint", False)):
            return
        x = self.x if self.x is not None else np.zeros(m.n)
        acc = icons.accent()
        hits = set()
        if self.frames:
            k = int(round(self.t * (len(self.frames) - 1)))
            for a, b in self.frames[k].get("hits", []):
                hits.update((a, b))
        bodies = [m.ground] + m.bodies
        for body in bodies:
            q = m.pose(x, body)
            color = QColor(220, 40, 40) if body.name in hits else (
                QColor(140, 140, 140) if body.fixed else acc)
            segs = self.body_segments.get(body.name)
            if segs is not None and len(segs):
                if body.fixed:
                    continue                     # the model already shows it
                pts = segs.reshape(-1, 3)
            else:
                pts = _box_segments(body, q)
                if not len(pts):
                    continue
                self._draw_segments(painter, pts, color, 1.4)
                continue
            R = body.rot(q)
            w = body.center + q[:3] + (pts - body.center) @ R.T
            self._draw_segments(painter, w, color, 1.6)
        # joints
        pts = []
        for j in m.joints:
            body = j.b if not j.b.fixed else j.a
            pts.append(body.world_point(m.pose(x, body), j.point))
        if pts:
            px, py, ok = self.app.world_to_pixels(np.array(pts))
            painter.setPen(QPen(acc, 1.6))
            painter.setBrush(QColor(255, 255, 255))
            for X, Y, o in zip(px, py, ok):
                if o:
                    painter.drawEllipse(QPointF(X, Y), 3.5, 3.5)
        # trajectories
        pen = QPen(acc, 1.4, Qt.DashLine)
        for tr in self.trace_pts:
            if len(tr) < 2:
                continue
            px, py, ok = self.app.world_to_pixels(tr)
            painter.setPen(pen)
            for i in range(len(tr) - 1):
                if ok[i] and ok[i + 1]:
                    painter.drawLine(QPointF(px[i], py[i]), QPointF(px[i + 1], py[i + 1]))

    # ---- video export ------------------------------------------------------------------
    def _settings(self):
        from PySide6.QtCore import QSettings
        return QSettings("IngeTrazo", "motion")

    def _ffmpeg_hint(self):
        try:
            v = self._settings().value("ffmpeg", "")
            return str(v) if v else None
        except Exception:
            return None

    def _export_dialog(self):
        from PySide6.QtWidgets import (QDialog, QDialogButtonBox, QFileDialog,
                                       QMessageBox, QProgressDialog)
        from . import video
        m = self.mechanism()
        if m.driver is None:
            self.say("Exporter la vidéo : pas de moteur.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Exporter la vidéo")
        form = QFormLayout(dlg)
        dur = QDoubleSpinBox()
        dur.setRange(2, 120)
        dur.setValue(8)
        dur.setSuffix(" s")
        form.addRow("Durée", dur)
        res = QComboBox()
        for text, wh in (("1920 × 1080", (1920, 1080)), ("1280 × 720", (1280, 720))):
            res.addItem(text, wh)
        form.addRow("Résolution", res)
        back = QCheckBox("Aller-retour (0 → 100 → 0 %)")
        back.setChecked(True)
        form.addRow(back)
        enc = QLabel()
        form.addRow("Format", enc)
        pick = QToolButton()
        pick.setText("Indiquer ffmpeg.exe…")
        form.addRow(pick)

        def refresh():
            kind, exe = video.mp4_backend(self._ffmpeg_hint())
            enc.setText({"qt": "MP4 (Qt Multimedia)", "ffmpeg": f"MP4 (ffmpeg : {exe})"}.get(
                kind, "AVI Motion-JPEG — pour du MP4, indiquer ffmpeg.exe"))
            pick.setVisible(kind != "qt")

        def choose():
            f, _ = QFileDialog.getOpenFileName(dlg, "ffmpeg", "", "ffmpeg (ffmpeg*)")
            if f:
                self._settings().setValue("ffmpeg", f)
            refresh()

        pick.clicked.connect(choose)
        refresh()
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec() != QDialog.Accepted:
            return
        kind, _ = video.mp4_backend(self._ffmpeg_hint())
        ext, filt = (".mp4", "Vidéo MP4 (*.mp4)") if kind else (".avi", "Vidéo AVI (*.avi)")
        path, _ = QFileDialog.getSaveFileName(self, "Exporter la vidéo", "motion" + ext, filt)
        if not path:
            return
        prog = QProgressDialog("Rendu de la vidéo…", "Annuler", 0, 100, self)
        prog.setWindowModality(Qt.WindowModal)
        prog.setMinimumDuration(0)

        def step(i, n):
            prog.setMaximum(n)
            prog.setValue(i)
            return not prog.wasCanceled()

        try:
            out, label = self.export_video(path, dur.value(), res.currentData(),
                                           back.isChecked(), progress=step)
        except Exception as exc:
            prog.close()
            QMessageBox.warning(self, "Exporter la vidéo", str(exc))
            return
        prog.close()
        self.say(f"Vidéo enregistrée : {out} — {label}." if out else "Export annulé.")

    def _viewport_image(self, width):
        """The IngeTrazo view (model + this overlay) as an image."""
        vp = self.app.viewport
        img = None
        render = getattr(vp, "render_image", None)
        if callable(render):
            try:
                img = render(width)
            except Exception:
                img = None
        lw, lh = max(vp.width(), 1), max(vp.height(), 1)
        if img is None or img.isNull():                  # no GL here: overlay only
            from PySide6.QtGui import QImage
            img = QImage(width, max(1, int(round(width * lh / lw))), QImage.Format_RGB32)
            img.fill(QColor(244, 244, 242))
        from PySide6.QtGui import QPainter
        p = QPainter(img)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.scale(img.width() / lw, img.height() / lh)
        self._force_paint = True
        try:
            self.paint(vp, p)
        finally:
            self._force_paint = False
            p.end()
        return img

    def _polys(self):
        """Face polygons of each body's groups (reference pose)."""
        if self.source != "model":
            return {}
        by = groups_by_uid(self._scene())
        out = {}
        for b in self.data["bodies"]:
            faces = []
            for u in b["groups"]:
                g = by.get(u)
                if g is None:
                    continue
                for mesh, aff in _placements(g):
                    for f in mesh.faces:
                        P = np.array([_xyz(v) for v in f.vertices])
                        if aff is not None:
                            P = P @ aff[0].T + aff[1]
                        faces.append(P)
            if faces:
                out[b["name"]] = faces
        return out

    def export_video(self, path, seconds=8.0, size=(1920, 1080), aller_retour=True,
                     fps=30, progress=None):
        """Render the motion to ``path`` (split screen). Returns (file, kind
        label), or (None, None) when ``progress(i, n)`` returned False."""
        from . import render, video
        m = self.mechanism()
        if m.driver is None:
            raise ValueError("pas de moteur")
        sweep_rows = self.frames or solver.sweep(m, max(self.pas.value(), 21))
        n = max(2, int(round(seconds * fps)))
        hold = min(int(0.5 * fps), n // 6)
        ease = lambda u: 0.5 - 0.5 * math.cos(math.pi * u)
        if aller_retour:
            run = (n - 3 * hold) // 2
            tl = ([0.0] * hold + [ease(i / max(run - 1, 1)) for i in range(run)] + [1.0] * hold
                  + [ease(1 - i / max(run - 1, 1)) for i in range(run)])
        else:
            run = n - 2 * hold
            tl = [0.0] * hold + [ease(i / max(run - 1, 1)) for i in range(run)]
        tl += [tl[-1]] * (n - len(tl))
        cam = getattr(self.app.viewport, "camera", None)
        yaw = float(getattr(cam, "yaw", math.radians(-45)))
        pitch = float(getattr(cam, "pitch", math.radians(25)))
        shaded = render.Shaded(m, self._polys())
        W, H = size
        u = H / 1080.0
        pane = ((W - 48 * u) / 2 - 8, H - 180 * u - 8)
        scale, centre = shaded.fit([r["x"] for r in sweep_rows], yaw, pitch, *pane)
        traces = self.trace_pts if self.buttons["trajectory"].isChecked() else []
        j, lo, hi = m.driver
        unit = (lambda v: f"{math.degrees(v):.1f}°") if j.kind == "pivot" else \
            (lambda v: f"{1000 * v:.0f} mm")
        name = {"chaise": "Chaise pliante en X", "porte": "Porte sectionnelle"}.get(
            self.source, "Mécanisme")
        writer = video.open_writer(path, W, H, fps, self._ffmpeg_hint())
        saved_x, saved_t = self.x, self.t
        x = None
        try:
            for i, t in enumerate(tl):
                if progress is not None and not progress(i, len(tl)):
                    writer.close()
                    return None, None
                f = t * (len(sweep_rows) - 1)
                k = min(int(f), len(sweep_rows) - 2)
                a = f - k
                guess = (1 - a) * sweep_rows[k]["x"] + a * sweep_rows[k + 1]["x"]
                x, ok, _ = solver.solve(m, lo + t * (hi - lo), guess)
                self.x, self.t = x, t
                hits = {nm for pair in collide.interferences(m, x) for nm in pair}
                cl = collide.clearances(m, x)
                info = [f"{j.name} : {unit(m.joint_value(j, x))}"]
                if cl:
                    info.append(f"jeu mini {1000 * max(cl[0]['distance'], 0):.1f} mm")
                info.append("collision : " + " / ".join(sorted(hits)) if hits else "aucune collision")
                if not ok:
                    info.append("position non atteinte")
                left = self._viewport_image(int(pane[0] * 1.5))
                frame = render.compose(
                    W, H, left,
                    lambda p, r: shaded.draw(p, r, x, yaw, pitch, scale, centre,
                                             hits, traces),
                    f"{name} — IngeTrazo Motion", info, t)
                writer.add(frame)
            if progress is not None:
                progress(len(tl), len(tl))
            out = writer.close()
        finally:
            self.x, self.t = saved_x, saved_t
            self.app.viewport.update()
        return out, writer.label

    def _draw_segments(self, painter, pts, color, width):
        px, py, ok = self.app.world_to_pixels(pts)
        painter.setPen(QPen(color, width))
        for i in range(0, len(pts) - 1, 2):
            if ok[i] and ok[i + 1]:
                painter.drawLine(QPointF(px[i], py[i]), QPointF(px[i + 1], py[i + 1]))


_BOX_EDGES = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7),
              (0, 4), (1, 5), (2, 6), (3, 7)]


def _box_segments(body, q):
    """World end points (pairs) of the wireframe of a body's boxes."""
    out = []
    for bx in body.boxes:
        c, R, h = collide.world_obb(body, q, bx)
        k = collide._corners((c, R, h))
        for i, j in _BOX_EDGES:
            out += [k[i], k[j]]
    return np.array(out) if out else np.zeros((0, 3))


def setup(app):
    panel = MotionPanel(app)
    dock = app.add_panel("Motion", panel, start_hidden=False)
    app.add_overlay(panel.paint)
    app.on_document_changed(panel.reload)

    def show(source=None):
        if source:
            panel.set_source(source)
        app.show_panel(dock)
        panel.mechanism()
        panel._scrub(panel.slider.value())

    sub = app.add_menu("Motion")
    if sub is not None:
        sub.addAction("Panneau Motion", lambda: show())
        sub.addAction("Exemple : chaise pliante", lambda: show("chaise"))
        sub.addAction("Exemple : porte sectionnelle", lambda: show("porte"))
    else:
        app.add_menu_action("Motion", lambda: show(),
                            tip="Mécanismes : pivots, glissières, rails, validation.")
    return panel
