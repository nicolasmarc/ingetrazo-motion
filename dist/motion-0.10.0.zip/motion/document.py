"""The mechanism as stored in the IngeTrazo document (pure, no Qt).

One JSON-safe dict (``app.set_document_data``), metres and radians::

    {"format": 1,
     "bodies": [{"name": "assise", "groups": ["<uid>", ...], "fixed": false}],
     "joints": [{"kind": "pivot" | "slider" | "guide", "name": "...",
                 "a": "<body>", "b": "<body>",
                 "point": [x, y, z], "axis": [x, y, z],      # pivot, slider
                 "rail": [[x, y, z], ...],                   # guide polyline
                 "limits": [lo, hi] | null},
                {"kind": "coupling", "name": "...", "a": "<body>", "b": "<body>",
                 "ja": "<joint>", "jb": "<joint>", "ratio": -0.5}],  # jb = ratio x ja
     "drivers": [{"joint": "<name>", "lo": 0.0, "hi": 1.57}, ...],
     "driver": <the first of "drivers"> | null,      # kept for 0.1-0.5 files
     "jeu_min": 0.005, "pas": 51,
     "couples": {"<joint>": 1.5},                   # torque motors (N m or N), dynamics
     "simulation": {"active": false, "duree": 4.0,  # dynamics in validate / video
                    "chocs": true,                  # parts touch each other (0.9: default)
                    "pesanteur": true},             # gravity (0.9: a box, ticked by default)
     "materiau": {"<uid>": "chene", ...},           # material of each group
     "matieres": {"<key>": {"name": ..., "density": ...}}}   # the document's own

A body is one or more IngeTrazo groups moving together; every body marked
``fixed`` is merged into the frame. Its collision boxes are fitted to the
groups' points (one box per group).
"""
import copy
import numpy as np
from .model import Mechanism, Box, Path, unit
from .lang import T as _T

FORMAT = 1


def empty():
    return {"format": FORMAT, "bodies": [], "joints": [], "drivers": [],
            "driver": None, "jeu_min": 0.005, "pas": 51, "materiau": {}, "matieres": {},
            "couples": {}, "simulation": {"active": False, "duree": 4.0, "chocs": True,
                                          "pesanteur": True},
            # 0.10: beads poured among the parts
            "billes": {"sources": [], "puits": [], "convoyeurs": {}}}


def normalized(data):
    """A complete, independent copy (missing keys filled in). A file with
    the single ``driver`` of 0.1-0.5 gets it as its one motor."""
    out = empty()
    if isinstance(data, dict):
        for k in out:
            if k in data and data[k] is not None:
                out[k] = copy.deepcopy(data[k])
    if isinstance(data, dict) and "drivers" not in data and out["driver"]:
        out["drivers"] = [copy.deepcopy(out["driver"])]
    out["driver"] = copy.deepcopy(out["drivers"][0]) if out["drivers"] else None
    # every part touches every other unless told otherwise (0.9): a file
    # that never said keeps the contacts
    out["simulation"].setdefault("chocs", True)
    out["simulation"].setdefault("pesanteur", True)       # gravity on unless unticked
    for k, v in (("sources", []), ("puits", []), ("convoyeurs", {})):
        out["billes"].setdefault(k, v)
    return out


def unique_name(data, stem):
    used = {b["name"] for b in data["bodies"]} | {j["name"] for j in data["joints"]}
    k = 1
    while f"{stem}{k}" in used:
        k += 1
    return f"{stem}{k}"


# -- beads (0.10) -------------------------------------------------------------

BEAD_SOURCE = {"name": "Source", "point": [0.0, 0.0, 0.0], "direction": [0.0, 0.0, -1.0],
               "diametre": 0.006, "diametre_max": 0.006, "debit": 100.0, "nombre": 500,
               "debut": 0.0, "fin": 1e9, "densite": 2500.0, "largeur": 0.03, "vitesse": 0.0,
               "couleur": [0.85, 0.65, 0.15]}


def add_bead_source(data, point, direction=(0.0, 0.0, -1.0), **values):
    """New bead source at ``point`` (world, m) pouring along ``direction``."""
    d = normalized(data)
    names = {s["name"] for s in d["billes"]["sources"]}
    k = 1
    while f"Source{k}" in names:
        k += 1
    src = copy.deepcopy(BEAD_SOURCE)
    src.update(name=f"Source{k}", point=[float(v) for v in point],
               direction=[float(v) for v in direction])
    src.update({k_: v for k_, v in values.items() if k_ in BEAD_SOURCE})
    d["billes"]["sources"].append(src)
    return d, src["name"]


def set_bead_source(data, name, **values):
    d = normalized(data)
    for s in d["billes"]["sources"]:
        if s["name"] == name:
            s.update({k: v for k, v in values.items() if k in BEAD_SOURCE})
    return d


def remove_bead_source(data, name):
    d = normalized(data)
    d["billes"]["sources"] = [s for s in d["billes"]["sources"] if s["name"] != name]
    return d


def set_sink(data, part, on=True):
    """A part that takes the beads it touches (and counts them)."""
    d = normalized(data)
    p = [n for n in d["billes"]["puits"] if n != part]
    if on:
        p.append(part)
    d["billes"]["puits"] = p
    return d


def set_conveyor(data, part, direction=None, speed=None):
    """A part whose surface carries the beads along ``direction`` at
    ``speed`` m/s (a belt); speed None: not a conveyor any more."""
    d = normalized(data)
    if speed is None:
        d["billes"]["convoyeurs"].pop(part, None)
    else:
        d["billes"]["convoyeurs"][part] = {"direction": [float(v) for v in direction],
                                          "vitesse": float(speed)}
    return d


def has_beads(data):
    return bool(normalized(data)["billes"]["sources"])


def bead_parts(data, mech, triangles_of_group):
    """[(part name, its body in ``mech``, its triangles turned outward)]."""
    d = normalized(data)
    by = {b.name: b for b in mech.bodies}
    out = []
    for b in d["bodies"]:
        body = mech.ground if b.get("fixed") else by.get(b["name"])
        if body is None:
            continue
        Ts = []
        for uid in b["groups"]:
            T = triangles_of_group(uid)
            if T is not None and len(T):
                T = np.asarray(T, float).reshape(-1, 3, 3)
                o = T.reshape(-1, 3).mean(axis=0)
                vol = np.einsum("ij,ij->i", T[:, 0] - o, np.cross(T[:, 1] - o, T[:, 2] - o)).sum()
                Ts.append(T[:, ::-1] if vol < 0 else T)
        if Ts:
            out.append((b["name"], body, np.concatenate(Ts)))
    return out


# -- editing ----------------------------------------------------------------

def add_body(data, uids, fixed, name=None):
    """New body from groups ``uids``; groups already used elsewhere are
    taken out of their previous body (a group belongs to one body)."""
    d = normalized(data)
    uids = [str(u) for u in uids]
    for b in d["bodies"]:
        b["groups"] = [u for u in b["groups"] if u not in uids]
    name = name or unique_name(d, _T("fixe") if fixed else _T("pièce"))
    d["bodies"].append({"name": name, "groups": uids, "fixed": bool(fixed)})
    return d, name


def add_joint(data, kind, a, b, point=None, axis=None, rail=None,
              limits=None, name=None, pitch=0.001):
    d = normalized(data)
    stem = {"pivot": "pivot", "slider": "glissière", "guide": "galet",
            "cylindrical": "pivot glissant", "ball": "rotule", "lock": "encastrement",
            "elastic": "élastique", "annular": "linéaire annulaire",
            "pointplane": "ponctuelle", "planar": "appui plan",
            "screw": "hélicoïdale", "contact": "contact"}[kind]
    stem = _T(stem)
    j = {"kind": kind, "name": name or unique_name(d, stem), "a": a, "b": b,
         "limits": list(limits) if limits is not None else None}
    if kind == "contact":                      # a: the part pushed, b: the one pushing
        pass
    elif kind == "guide":
        j["rail"] = [list(map(float, p)) for p in rail]
        j["point"] = list(map(float, point))
    elif kind in ("ball", "lock", "elastic"):
        j["point"] = list(map(float, point))
        if kind == "elastic":
            j.update(k_lin=1e5, k_rot=1e3, c_lin=50.0, c_rot=1.0)
    else:
        j["point"] = list(map(float, point))
        j["axis"] = list(map(float, unit(axis)))
        if kind == "screw":
            j["pitch"] = float(pitch)
    d["joints"].append(j)
    return d, j["name"]


def remove(data, name):
    """Remove a body (and its joints) or a joint."""
    d = normalized(data)
    d["bodies"] = [b for b in d["bodies"] if b["name"] != name]
    d["joints"] = [j for j in d["joints"]
                   if j["name"] != name and name not in (j["a"], j["b"])]
    names = {j["name"] for j in d["joints"]}            # couplings of a gone joint
    d["joints"] = [j for j in d["joints"] if j["kind"] != "coupling"
                   or (j.get("ja") in names and j.get("jb") in names)]
    names = {j["name"] for j in d["joints"]}
    d["drivers"] = [x for x in d["drivers"] if x["joint"] in names]
    # a bead source, or the part's role for the beads
    d["billes"]["sources"] = [x for x in d["billes"]["sources"] if x["name"] != name]
    d["billes"]["puits"] = [x for x in d["billes"]["puits"] if x != name]
    d["billes"]["convoyeurs"].pop(name, None)
    return normalized(d)


def merge_bodies(data, into, gone):
    """Part ``gone`` becomes part of ``into``: its groups move over, its
    joints with other parts now hold ``into``; the joints between the two
    (and what hangs on them: couplings, motors, torques) go, they would tie
    a part to itself. ``into`` keeps its name and whether it is fixed."""
    d = normalized(data)
    rec = {b["name"]: b for b in d["bodies"]}
    if into not in rec or gone not in rec or into == gone:
        raise ValueError("unknown part")
    rec[into]["groups"] = rec[into]["groups"] + [u for u in rec[gone]["groups"]
                                                 if u not in rec[into]["groups"]]
    d["bodies"] = [b for b in d["bodies"] if b["name"] != gone]
    joints = []
    for j in d["joints"]:
        if j["kind"] != "coupling" and {j["a"], j["b"]} == {into, gone}:
            continue
        j = dict(j)
        for k in ("a", "b"):
            if j.get(k) == gone:
                j[k] = into
        joints.append(j)
    names = {j["name"] for j in joints if j["kind"] != "coupling"}
    d["joints"] = [j for j in joints if j["kind"] != "coupling"
                   or (j.get("ja") in names and j.get("jb") in names)]
    names = {j["name"] for j in d["joints"]}
    d["drivers"] = [x for x in d["drivers"] if x["joint"] in names]
    d["couples"] = {n: v for n, v in d["couples"].items() if n in names}
    return normalized(d)


def add_coupling(data, ja, jb, ratio, name=None):
    """``jb`` turns ``ratio`` times ``ja`` (gears: -z1/z2)."""
    d = normalized(data)
    rec = {j["name"]: j for j in d["joints"]}
    a, b = rec[ja], rec[jb]
    j = {"kind": "coupling", "name": name or unique_name(d, "engrenage"),
         "a": a["b"], "b": b["b"], "ja": ja, "jb": jb, "ratio": float(ratio), "limits": None}
    d["joints"].append(j)
    return d, j["name"]


def apply_detection(data, parts, frame, proposals):
    """Bodies and joints from the detection (``motion.detect``):
    ``parts`` = {key: (name, [group uids])}, ``frame`` = key of the fixed
    part, ``proposals`` = the ticked ones. One body per part involved;
    joints keyed on the frame side first. Returns (data, [joint names])."""
    d = normalized(data)
    names = {}
    merge = {}                                   # pin -> the part it is fixed in
    for x in proposals:
        merge.update(getattr(x, "extra", {}).get("merge", {}))
    used = ({k for x in proposals for k in (x.a, x.b)} | {frame}) - set(merge)
    for key in [frame] + sorted((k for k in used if k != frame), key=lambda k: parts[k][0]):
        if key not in parts:
            continue
        nm, uids = parts[key][0], parts[key][1]
        if len(parts[key]) > 2 and parts[key][2]:    # a part already in the list: kept
            if any(b["name"] == nm for b in d["bodies"]):
                names[key] = nm
                continue
        uids = list(uids) + [u for pin, host in merge.items() if host == key
                             for u in parts[pin][1]]
        base = nm
        taken = {b["name"] for b in d["bodies"]} | {j["name"] for j in d["joints"]}
        k = 2
        while nm in taken:
            nm, k = f"{base} {k}", k + 1
        d, nm = add_body(d, uids, key == frame, nm)
        names[key] = nm
    made, by_prop = [], {}
    for x in proposals:
        if x.kind not in ("pivot", "slider", "ball", "lock"):
            continue
        a, b = (x.a, x.b) if x.b != frame else (x.b, x.a)
        stem = {"pivot": _T("pivot"), "slider": _T("glissière"), "ball": _T("rotule"),
                "lock": _T("encastrement")}[x.kind]
        jn = f"{stem} {names[a]}–{names[b]}"
        if jn in {b_["name"] for b_ in d["bodies"]} | {j["name"] for j in d["joints"]}:
            jn = unique_name(d, jn + " ")
        if x.kind in ("ball", "lock"):
            d, jn = add_joint(d, x.kind, names[a], names[b], point=x.point, name=jn)
            made.append(jn)
            continue
        d, jn = add_joint(d, x.kind, names[a], names[b], point=x.point, axis=x.axis, name=jn)
        made.append(jn)
        by_prop[id(x)] = (jn, a, b, np.asarray(x.axis, float))
    for x in proposals:
        if x.kind != "gears":
            continue
        pa, pb = x.extra["pivot_a"], x.extra["pivot_b"]
        if id(pa) not in by_prop or id(pb) not in by_prop:
            continue                       # a gear's pivot was not kept
        ja, a0, a1, ax_a = by_prop[id(pa)]
        jb, b0, b1, ax_b = by_prop[id(pb)]
        # angles are of the joint's second part about its axis, seen from
        # its first: turn the gear ratio into a ratio of those values
        f = x.extra["frame"]
        r = x.extra["ratio"]
        r *= (1 if a0 == f else -1) * (1 if b0 == f else -1)
        if ax_a @ ax_b < 0:
            r = -r
        d, cn = add_coupling(d, ja, jb, r, name=unique_name(d, _T("engrenage") + " "))
        made.append(cn)
    for x in proposals:
        if x.kind != "planetary":
            continue
        # the planet turns on its carrier -zr/zp times the carrier turns
        # (the ring held): the carrier's pivot leads the planet's
        pc, pp = x.extra["pivot_carrier"], x.extra["pivot_planet"]
        if id(pc) not in by_prop or id(pp) not in by_prop:
            continue
        ja, a0, a1, ax_a = by_prop[id(pc)]
        jb, b0, b1, ax_b = by_prop[id(pp)]
        car, pla = x.extra["carrier"], x.extra["planet"]
        r = x.extra["ratio"]
        r *= (1 if a1 == car else -1) * (1 if (b0 == car and b1 == pla) else -1)
        if ax_a @ ax_b < 0:
            r = -r
        d, cn = add_coupling(d, ja, jb, r, name=unique_name(d, _T("train épicycloïdal") + " "))
        made.append(cn)
    return d, made


PARAMS = ("spring", "damper", "slide_limits", "k_lin", "k_rot", "c_lin", "c_rot", "pitch")


def set_joint_params(data, name, **params):
    """Spring [stiffness, rest], damper, stops of the slide, elastic
    stiffness/damping of joint ``name`` (None removes a value)."""
    d = normalized(data)
    rec = next(j for j in d["joints"] if j["name"] == name)
    for k, v in params.items():
        if k not in PARAMS:
            raise KeyError(k)
        if v is None:
            rec.pop(k, None)
        else:
            rec[k] = list(map(float, v)) if isinstance(v, (list, tuple)) else float(v)
    return d


def set_torque(data, joint, value):
    """Torque motor (dynamics): ``value`` N m (pivot) or N (slider); None
    removes it."""
    d = normalized(data)
    if value is None:
        d["couples"].pop(joint, None)
    else:
        d["couples"][joint] = float(value)
    return d


def set_simulation(data, active, duree=None, chocs=None, pesanteur=None):
    """Dynamics on or off, its length (s), the contacts between parts and
    gravity (9.81 m/s², on by default)."""
    d = normalized(data)
    if pesanteur is not None:
        d["simulation"]["pesanteur"] = bool(pesanteur)
    d["simulation"]["active"] = bool(active)
    if duree is not None:
        d["simulation"]["duree"] = float(duree)
    if chocs is not None:
        d["simulation"]["chocs"] = bool(chocs)
    return d


def set_material(data, uids, key):
    """Groups ``uids`` are made of material ``key`` (None: forget it)."""
    d = normalized(data)
    for u in uids:
        if key is None:
            d["materiau"].pop(str(u), None)
        else:
            d["materiau"][str(u)] = key
    return d


def add_material(data, key, props):
    """A material of the document's own (or a library one overridden)."""
    from .materials import FIELDS
    d = normalized(data)
    d["matieres"][key] = {f: props[f] for f in FIELDS if f in props and props[f] is not None}
    return d


def mass_properties(data, triangles_of_group):
    """{body name: dict(mass, com, inertia, volume, materials, missing,
    friction, restitution)}
    from each group's closed triangles (world, reference pose) and its
    material; groups without a material are listed in ``missing`` and left
    out of the mass."""
    from . import massprops, materials
    d = normalized(data)
    lib = materials.library(d)
    out = {}
    for b in d["bodies"]:
        pieces, mats, missing, vol, surf = [], set(), [], 0.0, []
        for u in b["groups"]:
            T = triangles_of_group(u)
            if T is None or not len(T):
                continue
            key = d["materiau"].get(u)
            rec = lib.get(key) if key else None
            m, c, I, v = massprops.of_triangles(T, rec["density"] if rec else 1.0)
            vol += abs(v)
            if rec is None:
                missing.append(u)
                continue
            mats.add(rec["name"])
            if m < 0:                         # faces turned inward
                m, I = -m, -I
            pieces.append((m, c, I))
            surf.append((m, rec.get("friction"), rec.get("restitution")))
        m, c, I = massprops.combine(pieces) if pieces else (0.0, None, None)
        def mean(i):                          # by mass, over the known values
            vals = [(s[0], s[i]) for s in surf if s[i] is not None]
            tot = sum(w for w, _ in vals)
            return sum(w * v for w, v in vals) / tot if tot > 0 else None
        out[b["name"]] = dict(mass=m, com=c, inertia=I, volume=vol,
                              materials=sorted(mats), missing=missing,
                              friction=mean(1), restitution=mean(2))
    return out


def set_driver(data, joint, lo, hi):
    """``joint`` becomes the only motor."""
    d = normalized(data)
    d["drivers"] = [{"joint": joint, "lo": float(lo), "hi": float(hi)}]
    return normalized(d)


def add_driver(data, joint, lo, hi):
    """One more motor (or new travel for an existing one). All motors run
    on the same 0..100 %, each from its ``lo`` to its ``hi``."""
    d = normalized(data)
    rec = {"joint": joint, "lo": float(lo), "hi": float(hi)}
    for k, x in enumerate(d["drivers"]):
        if x["joint"] == joint:
            d["drivers"][k] = rec
            break
    else:
        d["drivers"].append(rec)
    return normalized(d)


def remove_driver(data, joint):
    d = normalized(data)
    d["drivers"] = [x for x in d["drivers"] if x["joint"] != joint]
    return normalized(d)


# -- geometry helpers ---------------------------------------------------------

def fit_box(points, name=""):
    """Bounding box of ``points``: the smaller of the axis-aligned box and
    the box along the principal directions."""
    P = np.asarray(points, float).reshape(-1, 3)
    if len(P) == 0:
        return None
    best = None
    frames = [np.eye(3)]
    if len(P) >= 3:
        c = P - P.mean(axis=0)
        _, _, vt = np.linalg.svd(c, full_matrices=False)
        R = vt.T
        if np.linalg.det(R) < 0:
            R[:, 2] *= -1
        frames.append(R)
    for R in frames:
        loc = P @ R
        lo, hi = loc.min(axis=0), loc.max(axis=0)
        half = np.maximum((hi - lo) / 2, 1e-6)
        vol = float(np.prod(half))
        if best is None or vol < best[0] - 1e-15:
            best = (vol, R @ ((lo + hi) / 2), half, R)
    return Box(best[1], best[2], best[3], name)


def chains(segments, tol=1e-6, max_turn=45.0):
    """Smooth polylines from a list of segments ((p0, p1), ...): two
    segments continue each other when they share an end and turn by less
    than ``max_turn`` degrees (a rail drawn as lines and arc segments is
    smooth, a roller mark drawn across it is not). Longest first."""
    segs = [(np.asarray(a, float), np.asarray(b, float)) for a, b in segments]
    left = list(range(len(segs)))
    cos_max = np.cos(np.radians(max_turn))
    out = []

    def same(p, q):
        return np.linalg.norm(p - q) <= tol

    def smooth(d0, d1):
        n0, n1 = np.linalg.norm(d0), np.linalg.norm(d1)
        return n0 > 0 and n1 > 0 and (d0 @ d1) / (n0 * n1) >= cos_max

    while left:
        i = left.pop(0)
        line = [segs[i][0], segs[i][1]]
        grown = True
        while grown:
            grown = False
            for k in list(left):
                a, b = segs[k]
                for end in (-1, 0):
                    tip, prev = line[end], line[end + 1 if end == 0 else -2]
                    if same(a, tip):
                        nxt = b
                    elif same(b, tip):
                        nxt = a
                    else:
                        continue
                    if not smooth(tip - prev, nxt - tip):
                        continue
                    if end == -1:
                        line.append(nxt)
                    else:
                        line.insert(0, nxt)
                    left.remove(k)
                    grown = True
                    break
        out.append(line)
    out.sort(key=lambda l: -sum(np.linalg.norm(l[i + 1] - l[i])
                                for i in range(len(l) - 1)))
    return out


def rail_and_rollers(segments):
    """Selection for a guide: the longest chain is the rail (run from its
    lowest end), every other segment marks one roller (its point nearest
    to the rail); rollers come in rail order, whatever the selection order."""
    cs = chains(segments)
    if not cs:
        raise ValueError(_T("sélectionner les arêtes du rail"))
    rail = cs[0]
    a, b = rail[0], rail[-1]                  # runs from its lowest end
    if (b[2], b[0], b[1]) < (a[2], a[0], a[1]):
        rail = rail[::-1]
    path = path_from_points(rail)
    rollers = []
    for other in cs[1:]:
        best = min(other, key=lambda p: np.linalg.norm(p - path.closest(p)[1]))
        rollers.append(best)
    rollers.sort(key=lambda p: path.closest(p)[0])     # in rail order
    return rail, rollers


def path_from_points(points):
    pts = [np.asarray(p, float) for p in points]
    path = Path(pts[0])
    for p in pts[1:]:
        if np.linalg.norm(p - path.end) > 1e-12:
            path.line_to(p)
    return path


def nearest_body(point, boxes_by_body, exclude=()):
    """Name of the body whose boxes come nearest ``point``."""
    p = np.asarray(point, float)
    best = (np.inf, None)
    for name, boxes in boxes_by_body.items():
        if name in exclude:
            continue
        for bx in boxes:
            loc = (p - bx.center) @ bx.R
            d = float(np.linalg.norm(loc - np.clip(loc, -bx.half, bx.half)))
            if d < best[0]:
                best = (d, name)
    return best[1]


# -- building the mechanism -----------------------------------------------------

def sphere_radius(points, box, tol=0.02):
    """Radius when the group is a ball (every point at the same distance
    from its box's centre, a cubic box), else None."""
    P = np.asarray(points, float).reshape(-1, 3)
    if len(P) < 20:
        return None
    h = np.asarray(box.half, float)
    if h.max() <= 0 or (h.max() - h.min()) > tol * h.max():
        return None
    r = np.linalg.norm(P - box.center, axis=1)
    if r.mean() <= 0 or r.std() > tol * r.mean() or r.max() > 1.05 * h.max():
        return None
    return float(h.max())


def body_boxes(data, points_of_group):
    """{body name: [Box per group]} from the groups' world points."""
    out = {}
    for b in data["bodies"]:
        boxes = []
        for uid in b["groups"]:
            pts = points_of_group(uid)
            if pts is not None and len(pts):
                bx = fit_box(pts, name=str(uid))
                if bx is not None:
                    bx.sphere = sphere_radius(pts, bx)
                    boxes.append(bx)
        out[b["name"]] = boxes
    return out


def build(data, points_of_group=lambda uid: None, names_of_group=None,
          triangles_of_group=None):
    """(Mechanism, problems). ``points_of_group(uid)`` gives the world
    points of a group (None when the group is gone); with
    ``triangles_of_group`` the parts get their mass, centre of gravity and
    inertia from the materials."""
    d = normalized(data)
    problems = []
    m = Mechanism()
    boxes = body_boxes(d, points_of_group)
    if names_of_group:
        for name, bxs in boxes.items():
            for bx in bxs:
                bx.name = names_of_group(bx.name) or bx.name
    bodies = {}
    fixed = [b for b in d["bodies"] if b["fixed"]]
    m.ground.name = fixed[0]["name"] if len(fixed) == 1 else "bâti"
    for b in fixed:
        m.ground.boxes.extend(boxes.get(b["name"], []))
        bodies[b["name"]] = m.ground
    for b in d["bodies"]:
        if b["fixed"]:
            continue
        bxs = boxes.get(b["name"], [])
        c = np.mean([bx.center for bx in bxs], axis=0) if bxs else np.zeros(3)
        bodies[b["name"]] = m.body(b["name"], c, bxs)
        if not bxs:
            problems.append(_T("{name} : aucun groupe trouvé dans le modèle", name=b['name']))
    if not fixed:
        problems.append(_T("aucune pièce fixe : ajouter une « pièce fixe »"))
    joints = {}
    # parts locked together (even through a third) are one solid: another
    # joint between them would hold them twice — a pin both turning on its
    # crank and locked to it left the contact solver without its push, and
    # it went through the Geneva wheel. The lock wins, the other is set aside
    root = {}

    def find(k):
        while root.get(k, k) != k:
            k = root[k]
        return k
    for j in d["joints"]:
        if j["kind"] == "lock":
            a, b = bodies.get(j["a"]), bodies.get(j["b"])
            if a is not None and b is not None:
                ra, rb = find(id(a)), find(id(b))
                if ra != rb:
                    root[ra] = rb
    for j in d["joints"]:
        a, b = bodies.get(j["a"]), bodies.get(j["b"])
        if a is None or b is None:
            problems.append(_T("{name} : pièce inconnue", name=j['name']))
            continue
        if a is b:
            problems.append(_T("{name} : relie une pièce à elle-même", name=j['name']))
            continue
        if j["kind"] not in ("lock", "coupling", "contact", "elastic") and find(id(a)) == find(id(b)):
            problems.append(_T("{name} : ignorée — « {a} » et « {b} » sont déjà encastrées "
                               "(supprimer l'une des deux liaisons)", name=j['name'], a=j['a'], b=j['b']))
            continue
        lim = tuple(j["limits"]) if j.get("limits") else None
        if j["kind"] in ("coupling", "contact"):
            continue                      # after every other joint
        k = j["kind"]
        if k == "pivot":
            mj = m.pivot(a, b, j["point"], j["axis"], lim, j["name"])
        elif k == "slider":
            mj = m.slider(a, b, j["point"], j["axis"], lim, j["name"])
        elif k == "cylindrical":
            mj = m.cylindrical(a, b, j["point"], j["axis"], lim, j["name"],
                               slide_limits=tuple(j["slide_limits"]) if j.get("slide_limits") else None)
        elif k == "ball":
            mj = m.ball(a, b, j["point"], j["name"])
        elif k == "lock":
            mj = m.lock(a, b, j["point"], j["name"])
        elif k == "annular":
            mj = m.annular(a, b, j["point"], j["axis"], j["name"])
        elif k == "pointplane":
            mj = m.point_plane(a, b, j["point"], j["axis"], j["name"])
        elif k == "planar":
            mj = m.planar(a, b, j["point"], j["axis"], j["name"])
        elif k == "screw":
            mj = m.screw(a, b, j["point"], j["axis"], j.get("pitch", 0.001), lim, j["name"])
        elif k == "elastic":
            mj = m.elastic(a, b, j["point"], j.get("k_lin", 1e5), j.get("k_rot", 1e3),
                           j.get("c_lin", 50.0), j.get("c_rot", 1.0), j["name"])
        else:
            mj = m.guide(a, b, j["point"], path_from_points(j["rail"]), lim, j["name"])
        if j.get("spring") and hasattr(mj, "spring"):
            mj.spring = tuple(j["spring"])
        if j.get("damper") and hasattr(mj, "damper"):
            mj.damper = float(j["damper"])
        joints[j["name"]] = mj
    for j in d["joints"]:
        if j["kind"] != "coupling":
            continue
        ja, jb = joints.get(j.get("ja")), joints.get(j.get("jb"))
        if ja is None or jb is None:
            problems.append(_T("{name} : liaison couplée inconnue", name=j['name']))
            continue
        joints[j["name"]] = m.couple(ja, jb, j["ratio"], j["name"])
    pushed = {}
    for j in d["joints"]:                     # contacts: a part pushed by others
        if j["kind"] == "contact" and j["a"] in bodies and j["b"] in bodies:
            pushed.setdefault(j["a"], []).append(bodies[j["b"]])
    m.contacts = set()
    if pushed:
        from .push import Pushed, PushGroup
        members = []
        for name, pushers in pushed.items():
            body = bodies[name]
            own = [mj for mj in joints.values()
                   if mj.kind in ("pivot", "slider") and body in (mj.a, mj.b)]
            # its pivot (or slider) with its carrier — the frame first — and
            # no other joint holding it (parts it carries are fine)
            own.sort(key=lambda mj: not (mj.b if mj.a is body else mj.a).fixed)
            others = [mj for mj in joints.values() if mj.kind != "coupling"
                      and body in (mj.a, mj.b) and mj is not (own[0] if own else None)
                      and not (mj.a is body and mj.b.name not in pushed)]
            if body.fixed or not own or others:
                problems.append(_T("contact : {p} doit tenir à une autre pièce par un seul "
                                   "pivot (ou une glissière), sans autre liaison", p=name))
                continue
            members.append(Pushed(body, own[0], pushers))
            for p_ in pushers:
                m.contacts.add(frozenset((name, p_.name)))
        if members:
            # any part may stop a pushed one (the rod a hanging pawl falls
            # onto), not only those named: the pushers are every other part
            mine = {id(mm.body) for mm in members}
            for mm in members:
                named = {id(p_) for p_ in mm.pushers}
                mm.pushers += [b_ for b_ in [m.ground] + m.bodies
                               if id(b_) not in named and b_ is not mm.body
                               and b_ is not mm.carrier]
            group = PushGroup(members)
            group.gravity = bool((d.get("simulation") or {}).get("pesanteur_contact", False))
            m.followers.append(group)
    if not (d.get("simulation") or {}).get("active") and fixed:
        # in kinematics a moving part tied to nothing fixed has no position
        # of its own: the solver turns it with its neighbours at random
        # (dynamics: a part may fall freely, a domino)
        links = {}
        for j in d["joints"]:
            if j["kind"] != "coupling" and j["a"] in bodies and j["b"] in bodies:
                links.setdefault(j["a"], set()).add(j["b"])
                links.setdefault(j["b"], set()).add(j["a"])
        seen = {b["name"] for b in fixed}
        todo = list(seen)
        while todo:
            for o in links.get(todo.pop(), ()):
                if o not in seen:
                    seen.add(o)
                    todo.append(o)
        for b in d["bodies"]:
            if not b["fixed"] and b["name"] not in seen:
                problems.append(_T("{name} : reliée à aucune pièce fixe, sa position n'est pas "
                                   "définie (ajouter une liaison ou en faire une pièce fixe)",
                                   name=b["name"]))
    for drv in d["drivers"]:
        if drv["joint"] in joints:
            m.add_driver(joints[drv["joint"]], drv["lo"], drv["hi"])
        else:
            problems.append(_T("moteur {name} : liaison inconnue", name=drv['joint']))
    m.torques = {n: v for n, v in d["couples"].items() if n in joints}
    m.simulation = dict(d["simulation"])
    if not m.drivers and m.bodies and not (m.simulation.get("active")):
        problems.append(_T("aucun moteur : choisir une liaison et « Moteur 0–100 % »"))
    m.masses = {}
    if triangles_of_group is not None:
        m.masses = mass_properties(d, triangles_of_group)
        for name, body in bodies.items():
            mp = m.masses.get(name)
            if mp and mp["mass"] > 0 and body is not m.ground:
                body.mass, body.com, body.inertia = mp["mass"], mp["com"], mp["inertia"]
            if mp:
                body.friction, body.restitution = mp.get("friction"), mp.get("restitution")
        m.surfaces = _surfaces(m, d, bodies, triangles_of_group, names_of_group)
    return m, problems


_CLOUDS = {}


def _surfaces(m, d, bodies, triangles_of_group, names_of_group=None):
    """The parts' sampled surfaces, for collisions on the real shapes."""
    from . import contact
    if not contact.available():
        return None
    tris = {}
    for b in d["bodies"]:
        for uid in b["groups"]:
            T = triangles_of_group(uid)
            if T is not None and len(T):
                T = np.asarray(T, float).reshape(-1, 3, 3)
                o = T.reshape(-1, 3).mean(axis=0)
                vol = np.einsum("ij,ij->i", T[:, 0] - o, np.cross(T[:, 1] - o, T[:, 2] - o)).sum()
                tris[uid] = T[:, ::-1] if vol < 0 else T     # faces turned outward
    if not tris:
        return None
    allp = np.concatenate([T.reshape(-1, 3) for T in tris.values()])
    h = contact.spacing(float(np.linalg.norm(allp.max(0) - allp.min(0))) * 0.75)
    # large flat faces (a 2 m box at 5 mm: 400 000 points a part) made
    # every check last seconds: the step widens so the whole mechanism
    # stays under a budget of points (the exact distance to the faces is
    # still computed where parts come close)
    area = sum(0.5 * float(np.linalg.norm(np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]),
                                          axis=1).sum()) for T in tris.values())
    fine, h = h, contact.budget_spacing(h, area)
    clouds = {}
    for b in d["bodies"]:
        body = bodies.get(b["name"])
        if body is None:
            continue
        items = clouds.setdefault(body.name, [])
        for uid in b["groups"]:
            T = tris.get(uid)
            if T is None:
                continue
            key = (uid, h, T.shape, float(T.sum()))
            if key not in _CLOUDS:
                if len(_CLOUDS) > 2000:
                    _CLOUDS.clear()
                _CLOUDS[key] = contact.surface_points(T, h)
            items.append(((names_of_group and names_of_group(uid)) or uid, _CLOUDS[key], T))
    S = contact.Surfaces(m, clouds, h)
    S.fine = fine          # the step the model's size asks for (before the budget)
    return S


def trajectory(mech, rows, body, point):
    """World positions of ``point`` (reference pose) of ``body`` along the
    solved ``rows`` (from ``solver.sweep`` or ``collide.validate``)."""
    return np.array([body.world_point(mech.pose(r["x"], body), point) for r in rows])
