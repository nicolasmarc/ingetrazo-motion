"""Shocks and resting contacts between parts (dynamics).

The parts are seen through their boxes (the ones Motion fits to every
group: a domino, a plank, a block are exact; a curved part is rounded up
to its box). Each box carries points on its corners and along its edges;
a point of one part that enters a box of another part pushes the two
apart, at that point:

    normal:      f_n = k d - c v_n           (never pulling, f_n >= 0)
    tangential:  f_t = -min(mu f_n, c_t |v_t|) v_t / |v_t|   (Coulomb)

d is how deep the point is in the box (towards its nearest face), v the
velocity of the point on the first part relative to the second one. The
stiffness k is set from the masses (a contact frequency, 400 Hz by
default: penetrations stay well under a tenth of a millimetre for parts
of a few grams falling a few centimetres) and the damping c from the
restitution of the two materials (e = 1 a perfect rebound, e = 0 none),
so the dynamics stays a smooth set of forces the step integrates.
Friction and restitution come from the parts' materials (the means of the
two), else 0.4 and 0.4.

A group whose points all lie at one distance from its centre is a ball
(:func:`motion.document.sphere_radius`): a ball against a ball or a box is
exact (one contact point) and follows Hertz's law, f = K d^1.5, as steel
balls do — what carries a blow along a row of touching balls (Newton's
cradle). K is set as stiff as the linear law at ``hertz_depth`` (0.1 mm).

This is a penalty method: quick and steady for blocks, plates, dominoes,
stops; it does not replace a finite-element impact study, and the parts do
not deform. Fixed parts (the frame, a table) take part as obstacles.
"""
import math
import numpy as np

_FRICTION, _RESTITUTION = 0.4, 0.4


def _box_samples(half, per_edge=3):
    """Corners and ``per_edge`` points inside every edge, in box axes."""
    s = np.array([[i, j, k] for i in (-1, 1) for j in (-1, 1) for k in (-1, 1)], float)
    pts = [s * half]
    for ax in range(3):
        o = [a for a in range(3) if a != ax]
        for i in (-1, 1):
            for j in (-1, 1):
                for t in np.linspace(-1, 1, per_edge + 2)[1:-1]:
                    p = np.zeros(3)
                    p[ax] = t * half[ax]
                    p[o[0]] = i * half[o[0]]
                    p[o[1]] = j * half[o[1]]
                    pts.append(p[None])
    return np.vstack(pts)


def _damping_ratio(e):
    e = min(max(float(e), 1e-3), 0.999)
    le = math.log(e)
    return -le / math.sqrt(math.pi ** 2 + le * le)


def _zeta(e):
    le = np.log(np.clip(e, 1e-3, 0.999))
    return -le / np.sqrt(math.pi ** 2 + le * le)


def _cross(a, b):
    """np.cross of (n, 3) rows, without its general-purpose overhead."""
    out = np.empty(np.broadcast_shapes(a.shape, b.shape))
    out[..., 0] = a[..., 1] * b[..., 2] - a[..., 2] * b[..., 1]
    out[..., 1] = a[..., 2] * b[..., 0] - a[..., 0] * b[..., 2]
    out[..., 2] = a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]
    return out

class Impacts:
    """Contact forces between the parts of ``dyn.m`` (a :class:`Dynamics`).

    ``frequency``: contact frequency (Hz) that sets the stiffness;
    ``dt``: the time step it will be integrated with (caps the friction
    damping so that the step stays stable); ``per_edge``: points along each
    edge of a box."""

    def __init__(self, dyn, frequency=400.0, dt=1e-4, per_edge=3, skip=(),
                 hertz_depth=1e-4, use_surfaces=True):
        self.dyn = dyn
        self.hertz_depth = float(hertz_depth)
        m = dyn.m
        self.freq = float(frequency)
        self.dt = float(dt)
        moving = {id(b): k for k, b in enumerate(dyn.bodies)}
        fixed = [b for b in [m.ground] + list(getattr(m, "bodies", [])) if b.fixed]
        joined = set()
        for j in m.joints:            # parts held by a joint do not knock each other
            for a in (getattr(j, "a", None),):
                b = getattr(j, "b", None)
                if a is not None and b is not None:
                    joined.add(frozenset((id(a), id(b))))
        self.joined = joined | {frozenset(map(id, p)) for p in skip}
        # one row per box
        self.box_body, self.box_k, self.box_c, self.box_R, self.box_h = [], [], [], [], []
        self.box_r = []
        self.box_pts = []
        for body in fixed + list(dyn.bodies):
            for bx in body.boxes:
                self.box_body.append(body)
                self.box_k.append(moving.get(id(body), -1))
                self.box_c.append(bx.center)
                self.box_R.append(bx.R)
                self.box_h.append(bx.half)
                self.box_r.append(float(getattr(bx, "sphere", None) or 0.0))
                self.box_pts.append(bx.center + _box_samples(bx.half, per_edge) @ bx.R.T)
        self.nb = len(self.box_body)
        self.box_k = np.array(self.box_k, int)
        self.box_c = np.array(self.box_c, float).reshape(-1, 3)
        self.box_R = np.array(self.box_R, float).reshape(-1, 3, 3)
        self.box_h = np.array(self.box_h, float).reshape(-1, 3)
        self.npts = len(self.box_pts[0]) if self.box_pts else 0
        self.box_pts = np.array(self.box_pts, float).reshape(self.nb, self.npts, 3)
        ids = [id(b) for b in self.box_body]
        same = np.array([[ids[i] == ids[k] for k in range(self.nb)] for i in range(self.nb)], bool)
        both_fixed = (self.box_k[:, None] < 0) & (self.box_k[None, :] < 0)
        held = np.array([[frozenset((ids[i], ids[k])) in self.joined for k in range(self.nb)]
                         for i in range(self.nb)], bool)
        self.allowed = ~(same | both_fixed | held)
        self.box_r = np.array(self.box_r, float)
        self.is_ball = self.box_r > 0
        # materials
        fr = [getattr(b, "friction", None) for b in self.box_body]
        rs = [getattr(b, "restitution", None) for b in self.box_body]
        self.box_mu = np.array([_FRICTION if v is None else v for v in fr], float)
        self.box_e = np.array([_RESTITUTION if v is None else v for v in rs], float)
        self.box_m = np.array([dyn.mass[id(b)] if k >= 0 else np.inf
                               for b, k in zip(self.box_body, self.box_k)], float)
        self.count = 0              # contact points at the last call
        self.deepest = 0.0          # deepest penetration seen (m)
        # parts with real surfaces touch on their surfaces, not their boxes
        S = getattr(m, "surfaces", None)
        self.S = S if S is not None and getattr(S, "data", None) else None
        self.body_boxes = {}
        for i, b in enumerate(self.box_body):
            self.body_boxes.setdefault(id(b), []).append(i)
        self.mesh_bodies = []
        if self.S is not None and use_surfaces:
            seen = set()
            for b in self.box_body:
                if id(b) not in seen and self.S.has(b) and not self.is_ball[self.body_boxes[id(b)][0]]:
                    seen.add(id(b))
                    self.mesh_bodies.append(b)
        mesh = {id(b) for b in self.mesh_bodies}
        on_mesh = np.array([id(b) in mesh for b in self.box_body], bool)
        self.allowed &= ~(on_mesh[:, None] & on_mesh[None, :])   # not twice
        gears = set()
        for j in m.joints:            # wheels in mesh: their coupling turns them
            if j.kind == "coupling":
                ja, jb = j.ja, j.jb
                for x_, y_ in ((ja.a, jb.a), (ja.a, jb.b), (ja.b, jb.a), (ja.b, jb.b)):
                    gears.add(frozenset((id(x_), id(y_))))
        held = {}                       # joints holding two parts together
        for j in m.joints:
            if j.kind != "coupling" and getattr(j, "a", None) is not None:
                held.setdefault(frozenset((id(j.a), id(j.b))), []).append(j)
        # parts locked together, even through a third (two arms bolted on
        # one wheel): one solid, they never knock each other
        root = {}

        def find(k):
            while root.get(k, k) != k:
                k = root[k]
            return k
        for j in m.joints:
            if j.kind in ("lock", "elastic") and getattr(j, "a", None) is not None:
                ra, rb = find(id(j.a)), find(id(j.b))
                if ra != rb:
                    root[ra] = rb
        self.mesh_pairs = []
        for i, a in enumerate(self.mesh_bodies):
            for b in self.mesh_bodies[i + 1:]:
                if a.fixed and b.fixed:
                    continue
                key = frozenset((id(a), id(b)))
                if key in gears:
                    continue
                js = held.get(key, [])
                if any(j.kind in ("lock", "elastic") for j in js) or find(id(a)) == find(id(b)):
                    continue                    # one part: they never knock
                # what touches or overlaps as drawn is the assembly (a shaft
                # in its bore, a hair of interference): only what comes into
                # contact afterwards pushes — a pin reaching the end of its
                # slot, a domino falling on the next. Round a pivot's axis
                # the rub of shaft and bore is the joint itself.
                # the pivots of either part: two parts on one axis through a
                # third (two pawls on a rocker's hub) rub there too
                mine = [j for j in m.joints if j.kind in ("pivot", "cylindrical", "screw")
                        and getattr(j, "axis", None) is not None
                        and ({id(j.a), id(j.b)} & {id(a), id(b)})]
                axes = [(tuple(map(float, j.point)), tuple(map(float, j.axis))) for j in mine]
                self.mesh_pairs.append((a, b, ("drawn", tuple(axes)) if axes else "drawn"))

    @property
    def surfaces_only(self):
        """Every contact is between real surfaces (no box or ball shocks):
        all of them can be constraints, and the step can be long."""
        return bool(self.mesh_pairs) and not bool(np.any(self.allowed))

    # -- the parts' boxes at pose x ------------------------------------------
    def _world(self, x, Rb):
        C = self.box_c.copy()
        R = self.box_R.copy()
        P = self.box_pts.copy()
        mv = self.box_k >= 0
        if mv.any():
            k = self.box_k[mv]
            if getattr(self, "_moving", None) is None:      # fixed for the run
                bodies = self.dyn.bodies
                self._moving = (np.array([b.index for b in bodies], int)[k],
                                np.array([b.center for b in bodies], float).reshape(-1, 3)[k])
            idx, c0 = self._moving
            q = np.asarray(x, float).reshape(-1, 6)[idx]
            t = c0 + q[:, :3]
            Rk = Rb[k]
            C[mv] = t + np.einsum("nij,nj->ni", Rk, self.box_c[mv] - c0)
            R[mv] = Rk @ self.box_R[mv]
            P[mv] = t[:, None, :] + (self.box_pts[mv] - c0[:, None, :]) @ np.transpose(Rk, (0, 2, 1))
        return C, R, P

    def forces(self, x, u, F, Rb=None, cogs=None):
        """Add the contact forces and torques (about each part's centre of
        gravity) to ``F``."""
        self.count = 0
        if self.nb < 2:
            return
        if Rb is None:
            Rb, cogs = self.dyn.poses(x)
        C, R, P = self._world(x, Rb)
        ext = np.abs(R) @ self.box_h[:, :, None]          # AABB half sizes
        ext = ext[:, :, 0]
        lo, hi = C - ext, C + ext
        ov = np.all((lo[:, None, :] <= hi[None, :, :]) & (lo[None, :, :] <= hi[:, None, :]), axis=2)
        ov &= self.allowed
        found = [self._box_points(C, R, P, ov), self._balls(C, R, ov),
                 None if self.hard else self._surfaces(x, lo, hi)]
        found = [f for f in found if f is not None]
        if not found:
            return
        a_box, b_box, p, n, d, share, hertz = (np.concatenate(v) for v in zip(*found))
        self._push(x, u, F, cogs, a_box, b_box, p, n, d, share, hertz)

    def _surfaces(self, x, lo, hi):
        """Points of a part gone into another part's real surface (both
        ways), for every pair whose boxes come close."""
        if not self.mesh_pairs:
            return None
        m = self.dyn.m
        r = 1.5 * self.S.h
        blo, bhi = {}, {}
        for b in self.mesh_bodies:
            ix = self.body_boxes[id(b)]
            blo[id(b)], bhi[id(b)] = lo[ix].min(axis=0), hi[ix].max(axis=0)
        out = []
        cache = self.__dict__.setdefault("_cand", {})
        self._calls = getattr(self, "_calls", 0) + 1
        for a, b, rest in self.mesh_pairs:
            if np.any(blo[id(a)] - r > bhi[id(b)]) or np.any(blo[id(b)] - r > bhi[id(a)]):
                continue
            qa, qb = m.pose(x, a), m.pose(x, b)
            for s_, t_, qs, qt in ((a, b, qa, qb), (b, a, qb, qa)):
                # the points that may touch, found again every few steps
                # (they move less than the margin meanwhile)
                key = (id(s_), id(t_))
                c = cache.get(key)
                if c is None or self._calls - c[0] >= self.hard_refresh:
                    idx, it = self.S.candidates(s_, t_, qs, qt, rest, 4.0 * self.S.h)
                    cache[key] = c = (self._calls, idx, it)
                p, n, d = self.S.penetrations_of(s_, t_, qs, qt, c[1], c[2])
                if len(d):                  # points of t_ in s_: t_ is pushed out along n
                    out.append((np.full(len(d), self.body_boxes[id(t_)][0]),
                                np.full(len(d), self.body_boxes[id(s_)][0]), p, n, d))
        if not out:
            return None
        a_box, b_box, p, n, d = (np.concatenate(v) for v in zip(*out))
        pair = a_box * self.nb + b_box
        cnt = np.bincount(pair, minlength=self.nb * self.nb)
        return a_box, b_box, p, n, d, cnt[pair].astype(float), np.zeros(len(d), bool)

    refresh = 8                       # steps between two searches of the points near
    hard = False                      # mesh contacts as unilateral constraints (Dynamics)
    per_pair = 6                      # points kept per pair of parts (hard contacts)
    hard_refresh = 2                  # calls between two searches (hard contacts)

    def radius(self, b):
        """Size of b (m): no point of it is further from its centre."""
        rad = self.__dict__.setdefault("_radius", {})
        R = rad.get(id(b))
        if R is None:
            if not b.boxes:
                return 0.0
            lo = np.min([np.asarray(bx.center) - np.linalg.norm(bx.half) for bx in b.boxes], axis=0)
            hi = np.max([np.asarray(bx.center) + np.linalg.norm(bx.half) for bx in b.boxes], axis=0)
            R = rad[id(b)] = float(np.linalg.norm(hi - lo))
        return R

    def _moved(self, b, q0, q1):
        """How far any point of b may have gone from pose q0 to q1."""
        if b.fixed if hasattr(b, "fixed") else False:
            return 0.0
        R = self.radius(b)
        R0, R1 = b.rot(q0), b.rot(q1)
        ang = math.acos(max(-1.0, min(1.0, (np.trace(R0.T @ R1) - 1.0) / 2.0)))
        return float(np.linalg.norm(np.asarray(q1[:3]) - np.asarray(q0[:3]))) + ang * R

    def _moved_rel(self, s, t, qs0, qt0, qs1, qt1):
        """How far any point of t has gone in s's frame between the two
        poses: exact, from the corners of t's box (a rigid motion moves
        no point further than the furthest corner)."""
        from .contact import _apply, _unapply
        B = self.S.data[t.name]
        lo, hi = B["lo"], B["hi"]
        C = np.array([[x, y, z] for x in (lo[0], hi[0]) for y in (lo[1], hi[1])
                      for z in (lo[2], hi[2])])
        L0 = _unapply(s, qs0, _apply(t, qt0, C))
        L1 = _unapply(s, qs1, _apply(t, qt1, C))
        return float(np.max(np.linalg.norm(L1 - L0, axis=1)))

    def _hard_mask(self, a, b, qa, qb, rest):
        """b's points that are no contact with a: round their common
        pivots (for good), and those drawn inside a until they come out —
        a pawl drawn a hair into a tooth pushes once it has left it."""
        axes = rest[1] if isinstance(rest, tuple) else ()
        held = self.__dict__.setdefault("_held", {})
        key = (id(a), id(b))
        h = held.get(key)
        if h is None:
            h = held[key] = self.S.drawn_inside(a, b).copy()
        ix = np.nonzero(h)[0]
        if len(ix):
            d = self.S.depths_at(a, b, qa, qb, ix)
            h[ix[~(d > 0.0)]] = False             # out (or far): a contact again
        return self.S.hard_hub(a, b, axes) | h

    def hard_points(self, x, reach):
        """Contacts of the parts' real surfaces as constraints: for every
        pair whose boxes come close, its few most telling points (the
        deepest, then the furthest from those kept) within ``reach`` of
        touching. (ka, kb, p, n, d): moving indices of the part pushed
        along n and of the other (-1: fixed), world points and normals,
        depths (> 0 in, < 0 a gap)."""
        empty = None
        if not self.mesh_pairs:
            return empty
        m = self.dyn.m
        moving = {id(b): k for k, b in enumerate(self.dyn.bodies)}
        lo_hi = {}
        for b in self.mesh_bodies:
            q = m.pose(x, b)
            Rb = b.rot(q)
            los, his = [], []
            for bx in b.boxes:
                c = b.world_point(q, bx.center)
                Rbx = bx.R if bx.R is not None else np.eye(3)
                e = np.abs(Rb @ Rbx) @ np.asarray(bx.half, float)
                los.append(c - e)
                his.append(c + e)
            lo_hi[id(b)] = (np.min(los, axis=0), np.max(his, axis=0))
        r = reach + 1.5 * self.S.h
        cache = self.__dict__.setdefault("_cand", {})
        self._calls = getattr(self, "_calls", 0) + 1
        out = []
        for pair_no, (a, b, rest) in enumerate(self.mesh_pairs):
            (la, ha), (lb, hb) = lo_hi[id(a)], lo_hi[id(b)]
            if np.any(la - r > hb) or np.any(lb - r > ha):
                continue
            qa, qb = m.pose(x, a), m.pose(x, b)
            P, N, D, KA, KB, ID = [], [], [], [], [], []
            for s_, t_, qs, qt in ((a, b, qa, qb), (b, a, qb, qa)):
                key = (id(s_), id(t_))
                c = cache.get(key)
                # searched again once the parts may have moved by half the
                # margin since: a turning wheel beside its frame is not
                # searched again step after step
                h = self.__dict__.get("_held", {}).get(key)
                released = False
                if h is not None and h.any():             # drawn inside: out yet?
                    ix = np.nonzero(h)[0]
                    out_ = ~(self.S.depths_at(s_, t_, qs, qt, ix) > 0.0)
                    if out_.any():
                        h[ix[out_]] = False
                        released = True
                if (c is None or released
                        or self._moved_rel(s_, t_, c[3], c[4], qs, qt) > c[5] - r):
                    # every point (a thin stop is not missed), within a
                    # wide margin: searched again only every few millimetres
                    margin = 12.0 * self.S.h
                    idx = self.S.near_points(s_, t_, qs, qt,
                                             self._hard_mask(s_, t_, qs, qt, rest), margin)
                    cache[key] = c = (self._calls, idx, None, np.array(qs), np.array(qt), margin)
                # the points left far are looked at again once the parts
                # may have closed by two steps
                f = self.__dict__.setdefault("_full", {})
                fq = f.get(key)
                full = fq is None or self._moved_rel(s_, t_, fq[0], fq[1], qs, qt) > 2.0 * self.S.h
                if full:
                    f[key] = (np.array(qs), np.array(qt))
                pv = self.__dict__.setdefault("_prev", {})
                pq = pv.get(key)
                mv = 1e9 if pq is None else self._moved_rel(s_, t_, pq[0], pq[1], qs, qt)
                pv[key] = (np.array(qs), np.array(qt))
                near, it = self.S.nearest_now(s_, t_, qs, qt, c[1], full=full,
                                              moved=mv, reach=reach)
                p, n, d = self.S.gaps_of(s_, t_, qs, qt, near, it, reach)
                if len(d):
                    P.append(p); N.append(n); D.append(d)
                    KA.append(np.full(len(d), moving.get(id(t_), -1)))
                    KB.append(np.full(len(d), moving.get(id(s_), -1)))
                    # a point's name from step to step: pair, side, index
                    ID.append(pair_no * 2 ** 33
                              + (s_ is b) * 2 ** 32 + self.S.last_ids.astype(np.int64))
            if not D:
                continue
            p, n, d = np.vstack(P), np.vstack(N), np.concatenate(D)
            ka, kb = np.concatenate(KA), np.concatenate(KB)
            ids = np.concatenate(ID)
            # the deepest, then spread out over what touches (a face resting
            # on its corners), then over what comes near
            keep = [int(np.argmax(d))]
            dmin = np.linalg.norm(p - p[keep[0]], axis=1)
            touch = d > -0.25 * self.S.h
            for pool in (touch, ~touch):
                while len(keep) < min(self.per_pair, len(d)):
                    cand = np.where(pool, dmin, -1.0)
                    k = int(np.argmax(cand))
                    if cand[k] < 0.5 * self.S.h:
                        break
                    keep.append(k)
                    dmin = np.minimum(dmin, np.linalg.norm(p - p[k], axis=1))
            ma = getattr(a, "friction", None)
            mb = getattr(b, "friction", None)
            f = math.sqrt((_FRICTION if ma is None else ma) * (_FRICTION if mb is None else mb))
            out.append((ka[keep], kb[keep], p[keep], n[keep], d[keep], np.full(len(keep), f),
                        ids[keep]))
        if not out:
            return empty
        self.count = sum(len(o[4]) for o in out)
        self.deepest = max(self.deepest, max(float(o[4].max()) for o in out))
        return tuple(np.concatenate(v) for v in zip(*out))

    def _box_points(self, C, R, P, ov):
        """Corners and edge points of a box inside another box (no ball)."""
        ov = ov & ~self.is_ball[:, None] & ~self.is_ball[None, :]
        ia, ib = np.nonzero(ov)          # points of box ia inside box ib
        if not len(ia):
            return None
        pts = P[ia]                                   # (n, s, 3)
        loc = (pts - C[ib][:, None, :]) @ R[ib]
        h = self.box_h[ib][:, None, :]
        depth = h - np.abs(loc)
        inside = np.all(depth > 0, axis=2)
        if not inside.any():
            return None
        pn, ps = np.nonzero(inside)
        d3 = depth[pn, ps]
        ax = np.argmin(d3, axis=1)
        d = d3[np.arange(len(ax)), ax]
        a_box, b_box = ia[pn], ib[pn]
        sign = np.sign(loc[pn, ps, ax])
        sign[sign == 0] = 1.0
        n = R[b_box, :, ax] * sign[:, None]           # out of box b, towards a
        p = pts[pn, ps]
        # stiffness shared among the points of one box pair
        pair = a_box * self.nb + b_box
        cnt = np.bincount(pair, minlength=self.nb * self.nb)
        return a_box, b_box, p, n, d, cnt[pair].astype(float), np.zeros(len(d), bool)

    def _balls(self, C, R, ov):
        """A ball (a sphere group) against another ball or a box: exact, one
        point, Hertz's law."""
        if not self.is_ball.any():
            return None
        upper = np.triu(np.ones_like(ov, bool), 1)
        out = []
        # ball / ball
        ia, ib = np.nonzero(ov & upper & self.is_ball[:, None] & self.is_ball[None, :])
        if len(ia):
            dv = C[ia] - C[ib]
            dist = np.linalg.norm(dv, axis=1)
            d = self.box_r[ia] + self.box_r[ib] - dist
            k = (d > 0) & (dist > 1e-12)
            if k.any():
                n = dv[k] / dist[k][:, None]                 # from b towards a
                p = C[ib][k] + n * (self.box_r[ib][k] - 0.5 * d[k])[:, None]
                out.append((ia[k], ib[k], p, n, d[k]))
        # ball (a) / box (b)
        ia, ib = np.nonzero(ov & self.is_ball[:, None] & ~self.is_ball[None, :])
        if len(ia):
            loc = np.einsum("nij,ni->nj", R[ib], C[ia] - C[ib])
            h = self.box_h[ib]
            q = np.clip(loc, -h, h)
            gap = loc - q
            dist = np.linalg.norm(gap, axis=1)
            r = self.box_r[ia]
            outside = dist > 1e-12
            # centre outside the box: nearest point of the box
            n_loc = np.where(outside[:, None], gap / np.maximum(dist, 1e-12)[:, None], 0.0)
            d = r - dist
            # centre inside: out through the nearest face
            dep = h - np.abs(loc)
            ax = np.argmin(dep, axis=1)
            sgn = np.sign(loc[np.arange(len(ax)), ax])
            sgn[sgn == 0] = 1.0
            n_in = np.zeros_like(loc)
            n_in[np.arange(len(ax)), ax] = sgn
            n_loc = np.where(outside[:, None], n_loc, n_in)
            d = np.where(outside, d, r + dep[np.arange(len(ax)), ax])
            k = d > 0
            if k.any():
                n = np.einsum("nij,nj->ni", R[ib][k], n_loc[k])   # box -> ball
                p = C[ia][k] - n * r[k][:, None]
                out.append((ia[k], ib[k], p, n, d[k]))
        if not out:
            return None
        a, b, p, n, d = (np.concatenate(v) for v in zip(*out))
        return a, b, p, n, d, np.ones(len(d)), np.ones(len(d), bool)

    def _push(self, x, u, F, cogs, a_box, b_box, p, n, d, share, hertz):
        dyn = self.dyn
        ka, kb = self.box_k[a_box], self.box_k[b_box]
        nbod = len(dyn.bodies)
        U = u.reshape(nbod, 6) if nbod else np.zeros((0, 6))

        def vel(k):
            ok = k >= 0
            kk = np.where(ok, k, 0)
            r = np.where(ok[:, None], p - cogs[kk], 0.0) if nbod else np.zeros_like(p)
            v = (U[kk, :3] + _cross(U[kk, 3:], r)) if nbod else np.zeros_like(p)
            return np.where(ok[:, None], v, 0.0), r

        va, ra = vel(ka)
        vb, rb = vel(kb)
        vrel = va - vb
        vn = np.einsum("ij,ij->i", vrel, n)
        vt = vrel - vn[:, None] * n
        ma, mb = self.box_m[a_box], self.box_m[b_box]
        fa, fb = np.isinf(ma), np.isinf(mb)
        ma_, mb_ = np.where(fa, 1.0, ma), np.where(fb, 1.0, mb)
        meff = np.where(fa, mb_, np.where(fb, ma_, ma_ * mb_ / (ma_ + mb_)))
        # a light part pushing a heavy one (a 9 g pawl driving a 400 g
        # wheel through its motor): the stiffness from the light one alone
        # lets it sink in; the geometric mean holds it, the step stays steady
        both = ~(fa | fb)
        meff = np.where(both, np.maximum(meff, np.sqrt(ma_ * mb_) * 0.5), meff)
        w = 2 * math.pi * self.freq
        k = meff * w * w / share                      # linear: N/m
        e = 0.5 * (self.box_e[a_box] + self.box_e[b_box])
        zeta = _zeta(e)
        # Hertz (balls): f = K d^1.5, as stiff as the linear law at the
        # reference depth; its stiffness grows with the depth
        dref = self.hertz_depth
        kh = np.where(hertz, 1.5 * k * np.sqrt(np.maximum(d, 0.0) / dref), k)
        felastic = np.where(hertz, k * dref * (np.maximum(d, 0.0) / dref) ** 1.5, k * d)
        c = 2 * zeta * np.sqrt(np.maximum(kh, 1e-12) * meff / share)
        fn = np.maximum(felastic - c * vn, 0.0)
        mu = 0.5 * (self.box_mu[a_box] + self.box_mu[b_box])
        ct = 0.5 * meff / share / self.dt               # the most a step can take
        vts = np.linalg.norm(vt, axis=1)
        ft_mag = np.minimum(mu * fn, ct * vts)
        tdir = np.where(vts[:, None] > 1e-12, vt / np.maximum(vts, 1e-12)[:, None], 0.0)
        f = fn[:, None] * n - ft_mag[:, None] * tdir    # on part a
        G = np.zeros((max(nbod, 1), 6))
        oa, ob = ka >= 0, kb >= 0
        np.add.at(G, ka[oa], np.hstack([f[oa], _cross(ra[oa], f[oa])]))
        np.add.at(G, kb[ob], -np.hstack([f[ob], _cross(rb[ob], f[ob])]))
        F[:6 * nbod] += G[:nbod].reshape(-1)
        self.count = len(f)
        self.deepest = max(self.deepest, float(d.max()))
